package com.udacity.PricingServiceServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PricingServiceServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
